def dump(value):
    print type(value), value

dump(1)
dump(1.0)
dump("one")

## <type 'int'> 1
## <type 'float'> 1.0
## <type 'string'> one
