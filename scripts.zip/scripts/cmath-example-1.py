import cmath

print "pi", "=>", cmath.pi
print "sqrt(-1)", "=>", cmath.sqrt(-1)

## pi => 3.14159265359
## sqrt(-1) => 1j
