def hello():
    print "example-plugin says hello"
