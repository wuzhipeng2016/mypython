import gzip

file = gzip.GzipFile("samples/sample.gz")

print file.read()

## Well it certainly looks as though we're in for
## a splendid afternoon's sport in this the 127th
## Upperclass Twit of the Year Show.
