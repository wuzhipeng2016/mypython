import linecache

print linecache.getline("linecache-example-1.py", 5)

## print linecache.getline("linecache-example-1.py", 5)
