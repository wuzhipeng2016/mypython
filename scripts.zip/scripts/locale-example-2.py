import locale

language, encoding = locale.getdefaultlocale()

print "language", language
print "encoding", encoding

## language sv_SE
## encoding cp1252
