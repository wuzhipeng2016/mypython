import math

print "e", "=>", math.e
print "pi", "=>", math.pi
print "hypot", "=>", math.hypot(3.0, 4.0)

# and many others...

## e => 2.71828182846
## pi => 3.14159265359
## hypot => 5.0
