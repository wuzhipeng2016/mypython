import mimify
import sys

mimify.unmimify("samples/sample.msg", sys.stdout, 1)
