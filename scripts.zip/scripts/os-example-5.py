import os

for file in os.listdir("samples"):
    print file

## sample.au
## sample.jpg
## sample.wav
## ...
