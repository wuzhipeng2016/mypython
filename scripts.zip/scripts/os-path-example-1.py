import os

filename = "my/little/pony"

print "using", os.name, "..."
print "split", "=>", os.path.split(filename)
print "splitext", "=>", os.path.splitext(filename)
print "dirname", "=>", os.path.dirname(filename)
print "basename", "=>", os.path.basename(filename)
print "join", "=>", os.path.join(os.path.dirname(filename),
                                 os.path.basename(filename))

## using nt ...
## split => ('my/little', 'pony')
## splitext => ('my/little/pony', '')
## dirname => my/little
## basename => pony
## join => my/little\pony
