import os

FILES = (
    os.curdir,
    "/",
    "file",
    "/file",
    "samples",
    "samples/sample.jpg",
    "directory/file",
    "../directory/file",
    "/directory/file"
    )

for file in FILES:
    print file, "=>",
    if os.path.exists(file):
        print "EXISTS",
    if os.path.isabs(file):
        print "ISABS",
    if os.path.isdir(file):
        print "ISDIR",
    if os.path.isfile(file):
        print "ISFILE",
    if os.path.islink(file):
        print "ISLINK",
    if os.path.ismount(file):
        print "ISMOUNT",
    print

## . => EXISTS ISDIR
## / => EXISTS ISABS ISDIR ISMOUNT
## file =>
## /file => ISABS
## samples => EXISTS ISDIR
## samples/sample.jpg => EXISTS ISFILE
## directory/file =>
## ../directory/file =>
## /directory/file => ISABS
