import packmail
import sys

packmail.packtree(sys.stdout, "samples")
