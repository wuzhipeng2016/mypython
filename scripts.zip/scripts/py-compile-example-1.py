import py_compile

# explicitly compile this module
py_compile.compile("py-compile-example-1.py")
