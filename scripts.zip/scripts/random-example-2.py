import random

# random choice from a list
for i in range(5):
    print random.choice([1, 2, 3, 5, 9])

## 2
## 3
## 1
## 9
## 1
