import readline # activate readline editing
