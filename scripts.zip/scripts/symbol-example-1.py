import symbol

print "print", symbol.print_stmt
print "return", symbol.return_stmt

## print 268
## return 274
