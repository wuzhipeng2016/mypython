import sys

print "hello"

sys.exit(1)

print "there"

## hello
