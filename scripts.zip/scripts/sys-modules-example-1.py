import sys

print sys.modules.keys()

## ['os.path', 'os', 'exceptions', '__main__', 'ntpath', 'strop', 'nt',
## 'sys', '__builtin__', 'site', 'signal', 'UserDict', 'string', 'stat']
