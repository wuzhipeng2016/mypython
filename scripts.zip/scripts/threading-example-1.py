import threading
import time, random

class Counter:
    def __init__(self):
        self.lock = threading.Lock()
        self.value = 0

    def increment(self):
        self.lock.acquire() # critical section
        self.value = value = self.value + 1
        self.lock.release()
        return value

counter = Counter()

class Worker(threading.Thread):

    def run(self):
        for i in range(10):
            # pretend we're doing something that takes 10-100 ms
            value = counter.increment() # increment global counter
            time.sleep(random.randint(10, 100) / 1000.0)
            print self.getName(), "-- task", i, "finished", value

#
# try it

for i in range(10):
    Worker().start() # start a worker

## Thread-1 -- task 0 finished 1
## Thread-3 -- task 0 finished 3
## Thread-7 -- task 0 finished 8
## Thread-1 -- task 1 finished 7
## Thread-4 -- task 0 Thread-5 -- task 0 finished 4
## finished 5
## Thread-8 -- task 0 Thread-6 -- task 0 finished 9
## finished 6
## ...
## Thread-6 -- task 9 finished 98
## Thread-4 -- task 9 finished 99
## Thread-9 -- task 9 finished 100
