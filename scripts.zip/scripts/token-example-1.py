import token

print "NUMBER", token.NUMBER
print "PLUS", token.STAR
print "STRING", token.STRING

## NUMBER 2
## PLUS 16
## STRING 3
