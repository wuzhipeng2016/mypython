def remove(sequence, item):
    if item in sequence:
        sequence.remove(item)
