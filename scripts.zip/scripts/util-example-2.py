def readfile(filename):
    file = open(filename, "r")
    return file.read()
