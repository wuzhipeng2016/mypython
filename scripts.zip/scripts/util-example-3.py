def readopenfile(file):
    return file.read()
